package com.deloitte.amazonregister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonRegisterApplication.class, args);
	}

}
