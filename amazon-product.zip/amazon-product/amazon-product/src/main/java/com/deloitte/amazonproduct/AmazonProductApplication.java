package com.deloitte.amazonproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonProductApplication.class, args);
	}
}
