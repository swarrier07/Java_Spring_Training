package com.deloitte.amazonlogin.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.amazonlogin.entity.Product;
import com.deloitte.amazonlogin.repo.UserRepository;

@RestController
public class SecurityController {

	@Autowired
	UserRepository userRepo;	
	@GetMapping("/home")
	public ResponseEntity<List<Product>> getProducts(){
		return new ResponseEntity<List<Product>>(userRepo.getAllProducts(), HttpStatus.OK);
	}

	@Autowired
	RestTemplate restTemplate;
//
//	@Bean
//	public RestTemplate restTemplate() {
//		return new RestTemplate();
//	}
	
	@Configuration
	class config {
		
		@Bean
		@LoadBalanced
		public RestTemplate restTemplate() {
			return new RestTemplate();
		}
	}

	@GetMapping(value = "/getCustomerProducts")
	public List<Object> getCustomerProducts() {
		Object objects = restTemplate.getForObject("http://amazon-product/product/getAll", Object.class);
		return Arrays.asList(objects);
	}
}
