package com.deloitte.amazoncart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
