package com.deloitte.amazoncart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.amazoncart.entity.Cart;
import com.deloitte.amazoncart.entity.Product;
import com.deloitte.amazoncart.repo.CartRepo;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	CartRepo cartRepo;
	
	@GetMapping("/getCart/{username}")
	public ResponseEntity<List<Cart>> getCart(@PathVariable String username) {
		return new ResponseEntity<List<Cart>>(cartRepo.getCartItems(username), HttpStatus.OK);
	}
	
	@PostMapping("/add/{username}/{productId}")
	public ResponseEntity<List<Product>> addCart(@PathVariable String username, @PathVariable int productId){
		Cart cart = new Cart(username, productId);
		cartRepo.save(cart);
		return new ResponseEntity<List<Product>>(cartRepo.getProductDetails(productId), HttpStatus.OK);
	}
}
