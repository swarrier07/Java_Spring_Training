package com.deloitte.amazoncart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cart")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Cart {
	
	@Id
	@Column(name = "unameAndId")
	private String unId;
    @Column(name = "username")
    private String username;
    @Column(name = "productId")
    private int productId;
    @Column(name = "quantity")
    private int qty;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getQty() {
		return qty;
	}
	public String getUnId() {
		return unId;
	}
	public Cart(String username, int productId) {
		super();
		this.unId = username + productId;
		this.username = username;
		this.productId = productId;
		this.qty = 1;
	}
	public Cart() {
	}
}
