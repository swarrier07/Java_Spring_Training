package com.deloitte.amazonlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
